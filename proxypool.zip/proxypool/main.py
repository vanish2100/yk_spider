#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from schedule.task import start_background_scheduler
from db.manager import check_database
from web.manager import start_web_server
from util.log import log_init
from spider.getproxy import *
from schedule.task import *

def main():
    log_init()
    check_database()

    grab_task();
    # grab = GrabProxy()
    # grab.start()
    # proxies = grab.web_proxies

    # unique_proxies = duplicate_filter(proxies)

    # verfy = VerifyProxy()
    # valid_proxies = verfy.validate_web_proxies(unique_proxies)

    # save(valid_proxies, output_proxies_file='proxy.txt')
    #start_background_scheduler()
    start_web_server()


if __name__ == '__main__':
    main()
